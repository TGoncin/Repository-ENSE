Student Name:		Tom Goncin
Student ID:		200412666

ENSE 271 - Lab 2 - Asset Inventories and Site-Maps



Website Name:		Launch Your Apparel
Website Link: 		https://www.startyourline.com/index.html